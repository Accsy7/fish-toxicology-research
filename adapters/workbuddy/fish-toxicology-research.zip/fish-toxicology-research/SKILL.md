---
name: fish-toxicology-research
description: "用于鱼类与有机污染物毒性研究的机制分析、相对风险比较、实验选物，以及已有研究的复核和成果生成。"
description_zh: "用于鱼类与有机污染物毒性研究的机制分析、相对风险比较、实验选物，以及已有研究的复核和成果生成。"
description_en: "Fish toxicology research, candidate comparison and experiment selection."
version: "1.5.1-rc.1"
license: "CC-BY-4.0; code: MIT"
author: "Fish toxicology research toolkit"
---

# 鱼类毒性研究

围绕研究问题组织资料、选择方法，形成能指导实验的判断。物种、物质、通路、终点和实验名额随课题确定。

## 接续项目

从用户描述和现有材料整理研究范围、参照与比较条件；仅询问会改变判断的缺失信息。项目有冻结基准和当前版本入口时沿用它们，续做读取当前正式分析，新课题建立[课题输入](assets/new-project.json)。文字、格式修订只处理受影响部分。

已接入工具的项目读取 `.fish-toxicology/workspace.json`，运行其中的 `query_tool doctor` 核对实际 skill、工具与资料库版本。首次接入按软件包的 `toolkit/INSTALL.md` 操作。按当前任务读取下列附文：

| 任务 | 阅读 |
|---|---|
| 新分析、补充研究、实验筹备 | [研究判断与方法选择](references/research-workflow.md) |
| 查库、运行工具、登记成果 | [工具接口](references/database-workflow.md) |
| 内容复核、纠错、研究交付 | [质量检查](references/quality-review.md) |
| 生成或维护工作簿、网页、图版 | [交付格式](references/accepted-formats.md) |
| 检索无结果、条件绑定与完成登记 | [来源条件与完成检查](references/evidence-and-completion.md) |
| 撰写或修改正文 | [表达审校](references/expression.md) |

## 工作逻辑

覆盖约定的全部物质和通路范围，按本题目标展开推导；范围调整逐项记录原因。每种物质的判断应说明预期影响、主要理由、适用条件、相反结果及可能改变判断的实验。资料有限时说明类推前提与置信程度；方法受阻时记录实际尝试、替代分析及影响，继续可开展的部分。

完整研究给出全范围相对风险顺序或分组，再按检验价值选择代表物。风险比较取决于作用与条件，文献数量只反映资料覆盖。代表物分别回答尚未解决的问题，名额结合预算与实验条件确定。

LLM负责方法选择与科学解释；代码提供查询、计算、记录和渲染能力。计算方法按适用性调用，参数与结果可追溯。正式分析连接原始资料和逐物质判断，图版、XLSX与网页从该版本生成。

## 完成研究

交付前复核原材料到最终文件的对应关系，修正同类错误影响的记录，登记实际复核者及范围。全范围判断、风险比较、代表物与检验问题齐备，实际文件可读且内容一致后结束本轮。实验参数中尚未确定的部分单列，按现有结果继续筹备。
